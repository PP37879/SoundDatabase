/*********************************************************************
 *
 * $Header$
 *
 * CMU ARPA Speech Project
 *
 * Copyright (c) 1996 Carnegie Mellon University.
 * All rights reserved.
 *
 *********************************************************************
 *
 * File: parse_cmd_ln.h
 * 
 * Description: 
 * 
 * Author: 
 * 
 *********************************************************************/

#ifndef PARSE_CMD_LN_H
#define PARSE_CMD_LN_H

int
parse_cmd_ln(int argc, char *argv[]);


#endif /* PARSE_CMD_LN_H */ 

